

var ST = {
    "ajax_url": "server/ajax.php",
    "vote_expires": "7",
    "_wpnonce": "649915da31",
    "user_logedin": false,
    "added_favorite": "Favorited",
    "add_favorite": "Favorite This Store",
    "login_warning": "Please login to continue...",
    "save_coupon": "Save this coupon",
    "saved_coupon": "Coupon Saved",
    "my_saved_coupons": [],
    "my_favorite_stores": []
};


var ST_User = {
    "ajax_url": "server/ajax.php",
    "current_action": "",
    "hide_txt": "Hide",
    "show_txt": "Show",
    "current_url": "\/st\/st-coupon\/",
    "_wpnonce": "649915da31",
    "cover_text": "Cover image",
    "avatar_text": "Avatar",
    "remove_text": "Remove",
    "upload_text": "Upload Photo"
};
